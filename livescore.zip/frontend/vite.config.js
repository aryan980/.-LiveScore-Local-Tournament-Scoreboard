import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// In dev, /api and /socket.io are proxied to the Express server so no CORS setup is needed.
const API = process.env.VITE_API_URL || "http://localhost:5000";
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { "/api": API, "/socket.io": { target: API, ws: true } },
  },
});
