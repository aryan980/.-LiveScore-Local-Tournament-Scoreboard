import { useEffect, useRef, useState } from "react";
import socket from "./socket";
import { api } from "./api";

// Generic loader: const { data, loading, error, reload } = useFetch("/matches")
export function useFetch(path, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: "" });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    if (!path) return;
    api(path)
      .then((data) => alive && setState({ data, loading: false, error: "" }))
      .catch((e) => alive && setState({ data: null, loading: false, error: e.message }));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, tick, ...deps]);
  return { ...state, reload: () => setTick((t) => t + 1) };
}

// Subscribe to a socket room and run `onUpdate` for every live match update.
// room = { feed: true } | { match: id } | { tournament: id }
export function useLiveRoom(room, onUpdate, onPoints) {
  const key = JSON.stringify(room);
  const h = useRef({});
  h.current = { onUpdate, onPoints }; // always call the latest handlers without re-subscribing
  useEffect(() => {
    const r = JSON.parse(key);
    const join = () => {
      if (r.feed) socket.emit("watch:feed");
      if (r.match) socket.emit("watch:match", r.match);
      if (r.tournament) socket.emit("watch:tournament", r.tournament);
    };
    const u = (m) => h.current.onUpdate && h.current.onUpdate(m);
    const p = (d) => h.current.onPoints && h.current.onPoints(d);
    join();
    socket.on("connect", join); // re-join rooms after a reconnect
    socket.on("match:update", u);
    socket.on("points:update", p);
    return () => {
      socket.off("connect", join);
      socket.off("match:update", u);
      socket.off("points:update", p);
      if (r.match) socket.emit("unwatch:match", r.match);
      if (r.tournament) socket.emit("unwatch:tournament", r.tournament);
    };
  }, [key]);
}

// Keeps a list of matches in sync with live updates (merge by _id)
export function useLiveList(initial, filter = () => true) {
  const [list, setList] = useState(initial || []);
  useEffect(() => setList(initial || []), [initial]);
  const onUpdate = (m) =>
    setList((cur) => {
      const has = cur.some((x) => x._id === m._id);
      if (has) return cur.map((x) => (x._id === m._id ? m : x));
      return filter(m) ? [m, ...cur] : cur;
    });
  return [list, onUpdate];
}
