import { useState } from "react";
import { useFetch } from "../hooks";
import MatchCard from "../components/MatchCard";

export default function History() {
  const [page, setPage] = useState(1);
  const { data, loading, error } = useFetch(`/matches?status=completed&limit=12&page=${page}`);
  return (
    <>
      <h1>Match history</h1>
      {error && <div className="alert">{error}</div>}
      {loading ? <p className="muted">Loading…</p> : (
        <div className="grid">
          {data.matches.map((m) => <MatchCard key={m._id} m={m} />)}
          {!data.matches.length && <div className="card muted">No completed matches yet.</div>}
        </div>
      )}
      {data && data.pages > 1 && (
        <div className="row center">
          <button className="btn ghost sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>← Prev</button>
          <span className="muted">Page {page} / {data.pages}</span>
          <button className="btn ghost sm" disabled={page >= data.pages} onClick={() => setPage(page + 1)}>Next →</button>
        </div>
      )}
    </>
  );
}
