import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useFetch, useLiveRoom, useLiveList } from "../hooks";
import MatchCard from "../components/MatchCard";
import PointsTable from "../components/PointsTable";
import { SPORT_ICON } from "../utils";

export default function TournamentDetail() {
  const { id } = useParams();
  const [tab, setTab] = useState("matches");
  const t = useFetch(`/tournaments/${id}`);
  const matches = useFetch(`/matches?tournament=${id}&limit=100`);
  const teams = useFetch(`/tournaments/${id}/teams`);
  const points = useFetch(`/tournaments/${id}/points`);
  const [list, onUpdate] = useLiveList(matches.data?.matches, () => true);

  // live scores + auto-refreshing points table
  useLiveRoom({ tournament: id }, onUpdate, () => points.reload());

  if (t.error) return <div className="alert">{t.error}</div>;
  if (!t.data) return <p className="muted">Loading…</p>;
  const tr = t.data.tournament;

  return (
    <>
      <div className="card head">
        <div className="big">{SPORT_ICON[tr.sport]}</div>
        <div>
          <h1>{tr.name} {tr.status !== "approved" && <span className={`pill ${tr.status}`}>{tr.status}</span>}</h1>
          <p className="muted">{tr.sport} · {tr.venue || "venue TBA"} · organiser {tr.organiser?.name}</p>
          {tr.description && <p>{tr.description}</p>}
        </div>
      </div>
      <div className="tabs">
        {["matches", "points", "teams"].map((k) => (
          <button key={k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>
            {{ matches: "Matches", points: "Points table", teams: "Teams" }[k]}
          </button>
        ))}
      </div>

      {tab === "matches" && (
        <div className="grid">
          {list.map((m) => <MatchCard key={m._id} m={m} />)}
          {!list.length && <div className="card muted">No matches scheduled yet.</div>}
        </div>
      )}
      {tab === "points" && <PointsTable data={points.data} />}
      {tab === "teams" && (
        <div className="grid">
          {(teams.data?.teams || []).map((tm) => (
            <Link key={tm._id} to={`/teams/${tm._id}`} className="card">
              <b>{tm.name}</b> <span className="muted">({tm.shortName})</span>
              <div className="muted small">{tm.captain ? `Captain: ${tm.captain} · ` : ""}{tm.players.length} players</div>
            </Link>
          ))}
          {teams.data && !teams.data.teams.length && <div className="card muted">No teams yet.</div>}
        </div>
      )}
    </>
  );
}
