import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useFetch } from "../hooks";
import { useAuth } from "../context/AuthContext";
import { SPORT_ICON } from "../utils";

export default function Admin() {
  const [tab, setTab] = useState("pending");
  return (
    <>
      <h1>Admin</h1>
      <div className="tabs">
        {[["pending", "Pending approval"], ["all", "All tournaments"], ["users", "Users"]].map(([k, l]) => (
          <button key={k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      {tab === "users" ? <Users /> : <Tournaments key={tab} status={tab === "pending" ? "pending" : ""} />}
    </>
  );
}

function Tournaments({ status }) {
  const { data, error, reload } = useFetch(`/admin/tournaments${status ? `?status=${status}` : ""}`);
  const [err, setErr] = useState("");
  const set = async (id, st) => {
    try { await api(`/admin/tournaments/${id}/status`, { method: "PATCH", body: { status: st } }); reload(); }
    catch (e) { setErr(e.message); }
  };
  return (
    <div className="stack">
      {(err || error) && <div className="alert">{err || error}</div>}
      {(data?.tournaments || []).map((t) => (
        <div key={t._id} className="card row between">
          <div>
            <Link to={`/tournaments/${t._id}`}><b>{SPORT_ICON[t.sport]} {t.name}</b></Link>
            <div className="muted small">by {t.organiser?.name} ({t.organiser?.email}) · <span className={`pill ${t.status}`}>{t.status}</span></div>
          </div>
          <div className="row">
            {t.status !== "approved" && <button className="btn sm" onClick={() => set(t._id, "approved")}>Approve</button>}
            {t.status !== "rejected" && <button className="btn danger sm" onClick={() => set(t._id, "rejected")}>Reject</button>}
          </div>
        </div>
      ))}
      {data && !data.tournaments.length && <div className="card muted">Nothing here.</div>}
    </div>
  );
}

function Users() {
  const { user: me } = useAuth();
  const { data, reload } = useFetch("/admin/users");
  const [err, setErr] = useState("");
  const setRole = async (id, role) => {
    try { await api(`/admin/users/${id}/role`, { method: "PATCH", body: { role } }); reload(); } catch (e) { setErr(e.message); }
  };
  return (
    <div className="card table-wrap">
      {err && <div className="alert">{err}</div>}
      <table className="points">
        <thead><tr><th className="l">Name</th><th className="l">Email</th><th>Role</th></tr></thead>
        <tbody>
          {(data?.users || []).map((u) => (
            <tr key={u._id}>
              <td className="l">{u.name}</td><td className="l">{u.email}</td>
              <td><select value={u.role} disabled={u._id === me.id} onChange={(e) => setRole(u._id, e.target.value)}>
                {["viewer", "scorer", "organiser", "admin"].map((r) => <option key={r}>{r}</option>)}</select></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
