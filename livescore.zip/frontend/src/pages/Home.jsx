import { useRef } from "react";
import { Link } from "react-router-dom";
import { useFetch, useLiveRoom, useLiveList } from "../hooks";
import MatchCard from "../components/MatchCard";
import { SPORT_ICON } from "../utils";

export default function Home() {
  const live = useFetch("/matches?status=live&limit=12");
  const upcoming = useFetch("/matches?status=scheduled&limit=6");
  const recent = useFetch("/matches?status=completed&limit=6");
  const tours = useFetch("/tournaments");

  // one socket subscription keeps all three lists fresh without a page reload
  const [liveList, onLive] = useLiveList(live.data?.matches, (m) => m.status === "live");
  const [upList, onUp] = useLiveList(upcoming.data?.matches, () => false);
  const [doneList, onDone] = useLiveList(recent.data?.matches, () => false);
  const lastStatus = useRef({});
  useLiveRoom({ feed: true }, (m) => {
    onLive(m); onUp(m); onDone(m); // merge the new score everywhere it is shown
    // when a match changes section (scheduled -> live -> completed) re-fetch the lists
    const prev = lastStatus.current[m._id];
    lastStatus.current[m._id] = m.status;
    if (prev !== m.status) { live.reload(); upcoming.reload(); recent.reload(); }
  });
  const liveNow = liveList.filter((m) => m.status === "live");

  return (
    <>
      <section className="hero">
        <h1>Follow every match, <span>live.</span></h1>
        <p>Scores for college and street tournaments: cricket, kabaddi and football. No refresh needed.</p>
      </section>

      <h2 className="sec">🔴 Live now</h2>
      {live.loading ? <p className="muted">Loading…</p> : liveNow.length ? (
        <div className="grid">{liveNow.map((m) => <MatchCard key={m._id} m={m} />)}</div>
      ) : <div className="card muted">No live matches right now. Check upcoming fixtures below.</div>}

      <div className="two-col">
        <div>
          <h2 className="sec">📅 Upcoming</h2>
          <div className="stack">{upList.filter((m) => m.status === "scheduled").map((m) => <MatchCard key={m._id} m={m} />)}
            {!upList.length && <div className="card muted">Nothing scheduled.</div>}</div>
        </div>
        <div>
          <h2 className="sec">✅ Recent results</h2>
          <div className="stack">{doneList.filter((m) => m.status === "completed").map((m) => <MatchCard key={m._id} m={m} />)}
            {!doneList.length && <div className="card muted">No results yet.</div>}</div>
          <Link to="/history" className="muted">View full match history →</Link>
        </div>
      </div>

      <h2 className="sec">🏟 Tournaments</h2>
      <div className="grid">
        {(tours.data?.tournaments || []).map((t) => (
          <Link key={t._id} to={`/tournaments/${t._id}`} className="card tour">
            <div className="big">{SPORT_ICON[t.sport]}</div>
            <div><b>{t.name}</b><div className="muted small">{t.sport} · by {t.organiser?.name}</div></div>
          </Link>
        ))}
        {tours.data && !tours.data.tournaments.length && <div className="card muted">No approved tournaments yet.</div>}
      </div>
    </>
  );
}
