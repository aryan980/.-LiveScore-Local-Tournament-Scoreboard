import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useFetch } from "../hooks";
import { SPORT_ICON, fmtDate } from "../utils";

export default function Organiser() {
  const mine = useFetch("/tournaments?mine=true");
  const [sel, setSel] = useState(null);
  const [f, setF] = useState({ name: "", sport: "football", venue: "", description: "" });
  const [err, setErr] = useState("");

  const create = async (e) => {
    e.preventDefault(); setErr("");
    try {
      const d = await api("/tournaments", { method: "POST", body: f });
      setF({ name: "", sport: "football", venue: "", description: "" });
      mine.reload(); setSel(d.tournament._id);
    } catch (e2) { setErr(e2.message); }
  };

  return (
    <>
      <h1>Organiser dashboard</h1>
      <div className="two-col wide-left">
        <div>
          <form className="card" onSubmit={create}>
            <h3>New tournament</h3>
            {err && <div className="alert">{err}</div>}
            <label>Name<input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
            <label>Sport<select value={f.sport} onChange={(e) => setF({ ...f, sport: e.target.value })}>
              <option value="football">Football</option><option value="cricket">Cricket</option><option value="kabaddi">Kabaddi</option></select></label>
            <label>Venue<input value={f.venue} onChange={(e) => setF({ ...f, venue: e.target.value })} /></label>
            <label>Description<input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></label>
            <button className="btn">Create</button>
            <p className="muted small">New tournaments need admin approval before the public can see them.</p>
          </form>
          <h3>My tournaments</h3>
          <div className="stack">
            {(mine.data?.tournaments || []).map((t) => (
              <button key={t._id} className={`card pick ${sel === t._id ? "sel" : ""}`} onClick={() => setSel(t._id)}>
                <span>{SPORT_ICON[t.sport]} <b>{t.name}</b></span><span className={`pill ${t.status}`}>{t.status}</span>
              </button>
            ))}
            {mine.data && !mine.data.tournaments.length && <div className="card muted">None yet.</div>}
          </div>
        </div>
        {sel ? <Manage key={sel} id={sel} /> : <div className="card muted">Select or create a tournament to manage its teams and matches.</div>}
      </div>
    </>
  );
}

function Manage({ id }) {
  const t = useFetch(`/tournaments/${id}`);
  const teams = useFetch(`/tournaments/${id}/teams`);
  const matches = useFetch(`/matches?tournament=${id}&limit=100`);
  const [team, setTeam] = useState({ name: "", shortName: "", captain: "", players: "" });
  const [m, setM] = useState({ teamA: "", teamB: "", scheduledAt: "", venue: "", scorerEmail: "" });
  const [msg, setMsg] = useState({ type: "", text: "" });
  const say = (text, type = "alert") => setMsg({ type, text });

  const run = async (fn, ok) => {
    try { await fn(); say(ok, "ok"); } catch (e) { say(e.message); }
  };
  const addTeam = (e) => { e.preventDefault(); run(async () => {
    await api(`/tournaments/${id}/teams`, { method: "POST", body: team });
    setTeam({ name: "", shortName: "", captain: "", players: "" }); teams.reload();
  }, "Team added"); };
  const addMatch = (e) => { e.preventDefault(); run(async () => {
    await api(`/tournaments/${id}/matches`, { method: "POST", body: { ...m, scheduledAt: m.scheduledAt || undefined, scorerEmail: m.scorerEmail || undefined } });
    setM({ ...m, teamA: "", teamB: "" }); matches.reload();
  }, "Match created"); };
  const assign = (mid) => { const email = prompt("Scorer's email:"); if (email) run(async () => {
    await api(`/matches/${mid}/scorer`, { method: "PATCH", body: { email } }); matches.reload();
  }, "Scorer assigned"); };
  const delMatch = (mid) => run(async () => { await api(`/matches/${mid}`, { method: "DELETE" }); matches.reload(); }, "Match deleted");
  const delTeam = (tid) => run(async () => { await api(`/teams/${tid}`, { method: "DELETE" }); teams.reload(); }, "Team deleted");

  if (!t.data) return <p className="muted">Loading…</p>;
  const tr = t.data.tournament;
  const tl = teams.data?.teams || [];

  return (
    <div>
      <div className="card">
        <div className="row between"><h2>{SPORT_ICON[tr.sport]} {tr.name}</h2><span className={`pill ${tr.status}`}>{tr.status}</span></div>
        {tr.status !== "approved" && <p className="muted">Waiting for admin approval. You can set up teams and matches now; scoring starts once approved.</p>}
        <Link to={`/tournaments/${id}`}>Open public page →</Link>
        {msg.text && <div className={msg.type === "ok" ? "toast-ok" : "alert"}>{msg.text}</div>}
      </div>

      <form className="card" onSubmit={addTeam}>
        <h3>Add team</h3>
        <div className="form-row">
          <input required placeholder="Team name" value={team.name} onChange={(e) => setTeam({ ...team, name: e.target.value })} />
          <input placeholder="Short (e.g. LIO)" maxLength={5} value={team.shortName} onChange={(e) => setTeam({ ...team, shortName: e.target.value })} />
          <input placeholder="Captain" value={team.captain} onChange={(e) => setTeam({ ...team, captain: e.target.value })} />
        </div>
        <input placeholder="Players, comma separated" value={team.players} onChange={(e) => setTeam({ ...team, players: e.target.value })} />
        <button className="btn sm">Add team</button>
        <div>{tl.map((x) => <span key={x._id} className="chip">{x.name} <button type="button" className="x" title="Delete team" onClick={() => delTeam(x._id)}>×</button></span>)}</div>
      </form>

      <form className="card" onSubmit={addMatch}>
        <h3>Schedule match</h3>
        <div className="form-row">
          <select required value={m.teamA} onChange={(e) => setM({ ...m, teamA: e.target.value })}><option value="">Team A</option>{tl.map((x) => <option key={x._id} value={x._id}>{x.name}</option>)}</select>
          <select required value={m.teamB} onChange={(e) => setM({ ...m, teamB: e.target.value })}><option value="">Team B</option>{tl.filter((x) => x._id !== m.teamA).map((x) => <option key={x._id} value={x._id}>{x.name}</option>)}</select>
        </div>
        <div className="form-row">
          <input type="datetime-local" value={m.scheduledAt} onChange={(e) => setM({ ...m, scheduledAt: e.target.value })} />
          <input placeholder="Venue" value={m.venue} onChange={(e) => setM({ ...m, venue: e.target.value })} />
          <input type="email" placeholder="Scorer email" value={m.scorerEmail} onChange={(e) => setM({ ...m, scorerEmail: e.target.value })} />
        </div>
        <button className="btn sm">Create match</button>
      </form>

      <h3>Matches</h3>
      <div className="stack">
        {(matches.data?.matches || []).map((x) => (
          <div key={x._id} className="card row between">
            <div><Link to={`/matches/${x._id}`}><b>{x.teamA.name} vs {x.teamB.name}</b></Link>
              <div className="muted small">{fmtDate(x.scheduledAt)} · <span className={`pill ${x.status}`}>{x.status}</span> · scorer: {x.scorer?.name || "unassigned"}</div></div>
            <div className="row">
              <button className="btn ghost sm" onClick={() => assign(x._id)}>Assign scorer</button>
              {x.status === "scheduled" && <button className="btn danger sm" onClick={() => delMatch(x._id)}>Delete</button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
