import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useFetch } from "../hooks";
import { fmtDate, fmtScore, nextBall, SPORT_ICON } from "../utils";

export default function Scorer() {
  const { data, loading, error, reload } = useFetch("/scorer/matches");
  const order = { live: 0, scheduled: 1, completed: 2 };
  const list = [...(data?.matches || [])].sort((a, b) => order[a.status] - order[b.status]);
  return (
    <>
      <h1>Scorer panel</h1>
      <p className="muted">Matches assigned to you. Every tap is pushed live to all viewers.</p>
      {error && <div className="alert">{error}</div>}
      {loading ? <p className="muted">Loading…</p> : (
        <div className="stack">
          {list.map((m) => <ScoreCard key={m._id} initial={m} onChange={reload} />)}
          {!list.length && <div className="card muted">No matches assigned yet. Ask an organiser to assign you using your email.</div>}
        </div>
      )}
    </>
  );
}

function ScoreCard({ initial }) {
  const [m, setM] = useState(initial);
  const [err, setErr] = useState("");
  const [note, setNote] = useState(initial.note || "");
  const sport = m.tournament.sport;
  const cricket = sport === "cricket";
  const live = m.status === "live";
  const unapproved = m.tournament.status !== "approved";

  const call = async (path, body) => {
    setErr("");
    try { setM((await api(`/matches/${m._id}/${path}`, { method: "PATCH", body })).match); }
    catch (e) { setErr(e.message); }
  };
  const bump = (key, patch, event) => call("score", { [key]: patch, event });
  const [finish, setFinish] = useState("");

  const Side = ({ k, team }) => {
    const s = m[k];
    const pts = sport === "kabaddi" ? [1, 2, 3] : cricket ? [1, 2, 3, 4, 6] : [1];
    return (
      <div className="side">
        <h4>{team.name}</h4>
        <div className="sc-big">{fmtScore(sport, s)}</div>
        <div className="btns">
          {pts.map((n) => <button key={n} disabled={!live} className="btn" onClick={() => bump(k, { main: s.main + n }, `${team.name} +${n}${cricket ? " run" + (n > 1 ? "s" : "") : sport === "football" ? " GOAL" : " pts"}`)}>+{n}</button>)}
          <button disabled={!live || s.main < 1} className="btn ghost" onClick={() => bump(k, { main: s.main - 1 }, `${team.name} score corrected -1`)}>−1</button>
        </div>
        {cricket && (
          <div className="btns">
            <button disabled={!live || s.wickets >= 10} className="btn danger" onClick={() => bump(k, { wickets: s.wickets + 1 }, `${team.name} WICKET (${s.wickets + 1} down)`)}>+ Wicket</button>
            <button disabled={!live} className="btn ghost" onClick={() => bump(k, { overs: nextBall(s.overs) })}>+ Ball ({s.overs} ov)</button>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="card">
      <div className="row between">
        <div>
          <b>{SPORT_ICON[sport]} {m.teamA.name} vs {m.teamB.name}</b>
          <div className="muted small">{m.tournament.name} · {fmtDate(m.scheduledAt)} · <span className={`pill ${m.status}`}>{m.status}</span></div>
        </div>
        <Link className="btn ghost sm" to={`/matches/${m._id}`}>Public view</Link>
      </div>
      {unapproved && <div className="alert">Tournament not approved yet; scoring is locked.</div>}
      {err && <div className="alert">{err}</div>}

      {m.status !== "scheduled" && <div className="sides"><Side k="scoreA" team={m.teamA} /><Side k="scoreB" team={m.teamB} /></div>}

      <div className="row wrap">
        {m.status === "scheduled" && <button className="btn" disabled={unapproved} onClick={() => call("status", { status: "live" })}>▶ Start match</button>}
        {live && (
          <>
            <input className="grow" placeholder="Note shown to viewers (e.g. Half time)" value={note} onChange={(e) => setNote(e.target.value)} />
            <button className="btn ghost" onClick={() => call("score", { note })}>Update note</button>
            <select value={finish} onChange={(e) => setFinish(e.target.value)} className="inline">
              <option value="">Result: auto (higher score)</option><option value="A">{m.teamA.name} won</option><option value="B">{m.teamB.name} won</option><option value="draw">Draw / tie</option>
            </select>
            <button className="btn danger" onClick={() => confirm("End the match and lock the result?") && call("status", { status: "completed", winner: finish || undefined, note })}>■ End match</button>
          </>
        )}
        {m.status === "completed" && <><span className="muted">{m.note}</span><button className="btn ghost sm" onClick={() => call("status", { status: "live" })}>Reopen (fix mistake)</button></>}
      </div>
    </div>
  );
}
