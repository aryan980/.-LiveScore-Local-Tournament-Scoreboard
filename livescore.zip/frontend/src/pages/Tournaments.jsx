import { useState } from "react";
import { Link } from "react-router-dom";
import { useFetch } from "../hooks";
import { SPORT_ICON } from "../utils";

export default function Tournaments() {
  const [sport, setSport] = useState("");
  const { data, loading, error } = useFetch(`/tournaments${sport ? `?sport=${sport}` : ""}`);
  return (
    <>
      <div className="row between">
        <h1>Tournaments</h1>
        <select value={sport} onChange={(e) => setSport(e.target.value)} className="inline">
          <option value="">All sports</option><option value="cricket">Cricket</option>
          <option value="kabaddi">Kabaddi</option><option value="football">Football</option>
        </select>
      </div>
      {error && <div className="alert">{error}</div>}
      {loading ? <p className="muted">Loading…</p> : (
        <div className="grid">
          {data.tournaments.map((t) => (
            <Link key={t._id} to={`/tournaments/${t._id}`} className="card tour">
              <div className="big">{SPORT_ICON[t.sport]}</div>
              <div><b>{t.name}</b><div className="muted small">{t.venue || "—"} · by {t.organiser?.name}</div>
                <p className="small">{t.description}</p></div>
            </Link>
          ))}
          {!data.tournaments.length && <div className="card muted">No tournaments found.</div>}
        </div>
      )}
    </>
  );
}
