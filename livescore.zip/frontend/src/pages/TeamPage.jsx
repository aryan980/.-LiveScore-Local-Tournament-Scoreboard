import { useParams, Link } from "react-router-dom";
import { useFetch } from "../hooks";
import MatchCard from "../components/MatchCard";

export default function TeamPage() {
  const { id } = useParams();
  const { data, error } = useFetch(`/teams/${id}`);
  if (error) return <div className="alert">{error}</div>;
  if (!data) return <p className="muted">Loading…</p>;
  const { team, tournament, record, matches } = data;
  // the match list from this endpoint carries no tournament object, so add it for the card
  const withT = matches.map((m) => ({ ...m, tournament }));
  return (
    <>
      <div className="card head">
        <div className="badge">{team.shortName}</div>
        <div>
          <h1>{team.name}</h1>
          <p className="muted"><Link to={`/tournaments/${tournament._id}`}>{tournament.name}</Link>{team.captain && ` · Captain ${team.captain}`}</p>
        </div>
      </div>
      <div className="stats">
        {[["Played", record.played], ["Won", record.won], ["Drawn", record.drawn], ["Lost", record.lost]].map(([k, v]) => (
          <div key={k} className="card stat"><b>{v}</b><span className="muted">{k}</span></div>
        ))}
      </div>
      <h3>Squad</h3>
      <div className="card">{team.players.length ? team.players.map((p) => <span key={p} className="chip">{p}</span>) : <span className="muted">No players listed.</span>}</div>
      <h3>Match history</h3>
      <div className="grid">{withT.map((m) => <MatchCard key={m._id} m={m} />)}{!withT.length && <div className="card muted">No matches yet.</div>}</div>
    </>
  );
}
