import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api } from "../api";
import { useLiveRoom } from "../hooks";
import { fmtScore, fmtDate, SPORT_ICON } from "../utils";

export default function MatchPage() {
  const { id } = useParams();
  const [m, setM] = useState(null);
  const [err, setErr] = useState("");
  const [flash, setFlash] = useState(false);

  useEffect(() => { api(`/matches/${id}`).then((d) => setM(d.match)).catch((e) => setErr(e.message)); }, [id]);
  // viewers see score changes instantly through Socket.IO
  useLiveRoom({ match: id }, (upd) => {
    if (upd._id !== id) return;
    setM(upd); setFlash(true); setTimeout(() => setFlash(false), 600);
  });

  if (err) return <div className="alert">{err}</div>;
  if (!m) return <p className="muted">Loading…</p>;
  const sport = m.tournament.sport;
  const win = (t) => m.status === "completed" && m.winner && String(m.winner) === String(t._id);

  return (
    <>
      <p><Link to={`/tournaments/${m.tournament._id}`} className="muted">← {SPORT_ICON[sport]} {m.tournament.name}</Link></p>
      <div className={`card scoreboard ${flash ? "flash" : ""}`}>
        <div className="sb-status">
          {m.status === "live" ? <span className="pill live">● LIVE</span> : m.status === "completed" ? <span className="pill done">FULL TIME</span> : <span className="pill soon">UPCOMING · {fmtDate(m.scheduledAt)}</span>}
          {m.venue && <span className="muted">📍 {m.venue}</span>}
        </div>
        <div className="sb-teams">
          {[m.teamA, m.teamB].map((t, i) => (
            <div key={t._id} className={`sb-team ${win(t) ? "win" : ""}`}>
              <Link to={`/teams/${t._id}`}>{t.name}</Link>
              <div className="sb-score">{m.status === "scheduled" ? "-" : fmtScore(sport, i ? m.scoreB : m.scoreA)}</div>
              {win(t) && <span className="pill done">Winner</span>}
            </div>
          ))}
        </div>
        {m.note && <p className="sb-note">{m.note}</p>}
        {m.scorer && <p className="muted small">Scorer: {m.scorer.name}</p>}
      </div>
      <h3>Match events</h3>
      <div className="card">
        {m.events.length ? [...m.events].reverse().map((e, i) => (
          <div key={i} className="event"><span className="muted">{new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span> {e.text}</div>
        )) : <span className="muted">No events yet.</span>}
      </div>
    </>
  );
}
