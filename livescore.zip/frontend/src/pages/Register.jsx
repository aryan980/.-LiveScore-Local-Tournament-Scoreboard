import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ROLES = [
  ["viewer", "Viewer: follow matches live"],
  ["scorer", "Scorer: update live scores"],
  ["organiser", "Organiser: create tournaments, teams & matches"],
];

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "", role: "viewer" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setErr("");
    try {
      const u = await register(f);
      nav({ organiser: "/organiser", scorer: "/scorer" }[u.role] || "/", { replace: true });
    } catch (e2) { setErr(e2.message); }
  };

  return (
    <form className="card auth" onSubmit={submit}>
      <h2>Create account</h2>
      {err && <div className="alert">{err}</div>}
      <label>Name<input required value={f.name} onChange={set("name")} /></label>
      <label>Email<input type="email" required value={f.email} onChange={set("email")} /></label>
      <label>Password<input type="password" minLength={6} required value={f.password} onChange={set("password")} /></label>
      <label>I am a…
        <select value={f.role} onChange={set("role")}>{ROLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
      </label>
      <button className="btn">Sign up</button>
      <p className="muted">Already registered? <Link to="/login">Login</Link></p>
    </form>
  );
}
