// Fetch API wrapper: adds the access token, and on 401 silently uses the refresh token once.
const BASE = import.meta.env.VITE_API_URL || "";
const KEY = "livescore_tokens";

export const tokens = {
  get: () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } },
  set: (t) => localStorage.setItem(KEY, JSON.stringify(t)),
  clear: () => localStorage.removeItem(KEY),
};

let refreshing = null; // single-flight so parallel 401s trigger only one refresh
async function refresh() {
  const { refreshToken } = tokens.get();
  if (!refreshToken) return false;
  refreshing ||= fetch(`${BASE}/api/auth/refresh`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ refreshToken }),
  })
    .then(async (r) => {
      if (!r.ok) { tokens.clear(); return false; }
      const d = await r.json();
      tokens.set({ accessToken: d.accessToken, refreshToken: d.refreshToken });
      return true;
    })
    .catch(() => false)
    .finally(() => { refreshing = null; });
  return refreshing;
}

async function raw(path, { method = "GET", body } = {}) {
  const { accessToken } = tokens.get();
  return fetch(`${BASE}/api${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...(accessToken && { Authorization: `Bearer ${accessToken}` }) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

export async function api(path, opts = {}) {
  let res = await raw(path, opts);
  if (res.status === 401 && !path.startsWith("/auth/") && (await refresh())) res = await raw(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}
