import { Link } from "react-router-dom";

export default function PointsTable({ data }) {
  if (!data) return null;
  const { rows, rules, sport } = data;
  const goals = sport === "football" ? "GD" : "Diff";
  return (
    <div className="card table-wrap">
      <table className="points">
        <thead>
          <tr><th>#</th><th className="l">Team</th><th>P</th><th>W</th><th>D</th><th>L</th><th>{goals}</th><th>Pts</th></tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.teamId} className={r.position <= 2 && r.played ? "top" : ""}>
              <td>{r.position}</td>
              <td className="l"><Link to={`/teams/${r.teamId}`}>{r.name}</Link></td>
              <td>{r.played}</td><td>{r.won}</td><td>{r.drawn}</td><td>{r.lost}</td>
              <td>{r.diff > 0 ? `+${r.diff}` : r.diff}</td><td><b>{r.points}</b></td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="8" className="muted">No teams yet</td></tr>}
        </tbody>
      </table>
      <p className="muted small">Win {rules.win} · Draw/Tie {rules.draw} · Loss {rules.loss} · calculated automatically from completed matches</p>
    </div>
  );
}
