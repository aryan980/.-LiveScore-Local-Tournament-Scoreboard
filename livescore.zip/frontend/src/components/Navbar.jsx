import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  return (
    <header className="nav">
      <div className="nav-inner">
        <Link to="/" className="logo">🏆 Live<span>Score</span></Link>
        <nav>
          <NavLink to="/" end>Live</NavLink>
          <NavLink to="/tournaments">Tournaments</NavLink>
          <NavLink to="/history">History</NavLink>
          {user?.role === "organiser" && <NavLink to="/organiser">Organiser</NavLink>}
          {user?.role === "scorer" && <NavLink to="/scorer">Scorer</NavLink>}
          {user?.role === "admin" && <NavLink to="/admin">Admin</NavLink>}
        </nav>
        <div className="nav-right">
          {user ? (
            <>
              <span className="who">{user.name} <em className={`role r-${user.role}`}>{user.role}</em></span>
              <button className="btn ghost sm" onClick={async () => { await logout(); nav("/"); }}>Logout</button>
            </>
          ) : (
            <>
              <Link className="btn ghost sm" to="/login">Login</Link>
              <Link className="btn sm" to="/register">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
