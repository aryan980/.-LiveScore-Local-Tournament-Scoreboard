import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

// Client-side RBAC guard (the server enforces the same rules independently)
export default function ProtectedRoute({ roles, children }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <p className="muted">Loading…</p>;
  if (!user) return <Navigate to="/login" state={{ from: loc.pathname }} replace />;
  if (roles && user.role !== "admin" && !roles.includes(user.role))
    return <div className="card"><h2>Access denied</h2><p className="muted">This page needs the {roles.join(" / ")} role.</p></div>;
  return children;
}
