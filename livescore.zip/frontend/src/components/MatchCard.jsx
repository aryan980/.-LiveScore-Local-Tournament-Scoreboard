import { Link } from "react-router-dom";
import { fmtScore, fmtDate, SPORT_ICON } from "../utils";

// Compact scoreboard card used on home, tournament and history pages
export default function MatchCard({ m }) {
  const sport = m.tournament?.sport;
  const win = (id) => m.status === "completed" && m.winner && String(m.winner) === String(id);
  return (
    <Link to={`/matches/${m._id}`} className={`match-card ${m.status}`}>
      <div className="mc-top">
        <span className="muted">{SPORT_ICON[sport]} {m.tournament?.name}</span>
        {m.status === "live" ? <span className="pill live">● LIVE</span>
          : m.status === "completed" ? <span className="pill done">FT</span>
          : <span className="pill soon">{fmtDate(m.scheduledAt)}</span>}
      </div>
      <div className={`mc-row ${win(m.teamA._id) ? "win" : ""}`}><span>{m.teamA.name}</span><b>{m.status === "scheduled" ? "-" : fmtScore(sport, m.scoreA)}</b></div>
      <div className={`mc-row ${win(m.teamB._id) ? "win" : ""}`}><span>{m.teamB.name}</span><b>{m.status === "scheduled" ? "-" : fmtScore(sport, m.scoreB)}</b></div>
      {m.note && <div className="mc-note">{m.note}</div>}
    </Link>
  );
}
