import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Tournaments from "./pages/Tournaments";
import TournamentDetail from "./pages/TournamentDetail";
import MatchPage from "./pages/MatchPage";
import TeamPage from "./pages/TeamPage";
import History from "./pages/History";
import Organiser from "./pages/Organiser";
import Scorer from "./pages/Scorer";
import Admin from "./pages/Admin";

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/tournaments" element={<Tournaments />} />
          <Route path="/tournaments/:id" element={<TournamentDetail />} />
          <Route path="/matches/:id" element={<MatchPage />} />
          <Route path="/teams/:id" element={<TeamPage />} />
          <Route path="/history" element={<History />} />
          <Route path="/organiser" element={<ProtectedRoute roles={["organiser"]}><Organiser /></ProtectedRoute>} />
          <Route path="/scorer" element={<ProtectedRoute roles={["scorer"]}><Scorer /></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute roles={["admin"]}><Admin /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
