import { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api, tokens } from "../api";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // restore session on page load
  useEffect(() => {
    if (!tokens.get().accessToken) return setLoading(false);
    api("/auth/me").then((d) => setUser(d.user)).catch(() => tokens.clear()).finally(() => setLoading(false));
  }, []);

  const authenticate = useCallback(async (path, body) => {
    const d = await api(path, { method: "POST", body });
    tokens.set({ accessToken: d.accessToken, refreshToken: d.refreshToken });
    setUser(d.user);
    return d.user;
  }, []);

  const login = (email, password) => authenticate("/auth/login", { email, password });
  const register = (form) => authenticate("/auth/register", form);
  const logout = async () => {
    await api("/auth/logout", { method: "POST", body: { refreshToken: tokens.get().refreshToken } }).catch(() => {});
    tokens.clear();
    setUser(null);
  };

  return <AuthContext.Provider value={{ user, loading, login, register, logout }}>{children}</AuthContext.Provider>;
}
