export const SPORT_ICON = { cricket: "🏏", kabaddi: "🤼", football: "⚽" };

// "120/3 (12.4)" for cricket, plain number for goals / points
export function fmtScore(sport, s) {
  if (!s) return "0";
  return sport === "cricket" ? `${s.main}/${s.wickets} (${s.overs})` : String(s.main);
}
export const fmtDate = (d) =>
  new Date(d).toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

// add one legal ball: 5.5 -> 6.0
export function nextBall(overs) {
  const o = Math.floor(overs);
  const b = Math.round((overs - o) * 10);
  return b + 1 >= 6 ? o + 1 : Math.round((o + (b + 1) / 10) * 10) / 10;
}
