import { io } from "socket.io-client";

// One shared connection for the whole app (same origin in dev thanks to the Vite proxy)
const socket = io(import.meta.env.VITE_API_URL || undefined, { transports: ["websocket"] });
export default socket;
