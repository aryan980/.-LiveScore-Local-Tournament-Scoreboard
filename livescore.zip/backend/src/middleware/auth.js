const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { HttpError, wrap } = require("../utils/http");

// Verifies the Bearer access token and attaches req.user
const authenticate = wrap(async (req, res, next) => {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) throw new HttpError(401, "Authentication required");
  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
  } catch {
    throw new HttpError(401, "Invalid or expired token");
  }
  const user = await User.findById(payload.sub);
  if (!user) throw new HttpError(401, "User no longer exists");
  req.user = user;
  next();
});

// Same as authenticate but anonymous visitors are allowed (req.user stays undefined)
const optionalAuth = wrap(async (req, res, next) => {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return next();
  try {
    const payload = jwt.verify(h.slice(7), process.env.JWT_ACCESS_SECRET);
    req.user = await User.findById(payload.sub);
  } catch {
    /* ignore: treat as anonymous */
  }
  next();
});

// RBAC: authorize("organiser", "admin") ...  (admin is always allowed)
const authorize = (...roles) => (req, res, next) => {
  if (!req.user) return next(new HttpError(401, "Authentication required"));
  if (req.user.role === "admin" || roles.includes(req.user.role)) return next();
  next(new HttpError(403, `Requires role: ${roles.join(" or ")}`));
};

module.exports = { authenticate, optionalAuth, authorize };
