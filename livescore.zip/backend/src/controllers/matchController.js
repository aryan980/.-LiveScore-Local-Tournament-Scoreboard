const Match = require("../models/Match");
const Team = require("../models/Team");
const User = require("../models/User");
const { HttpError, wrap } = require("../utils/http");
const { isId, loadTournament, loadOwnedTournament, approvedTournamentIds } = require("../utils/access");
const { broadcastMatch, broadcastPoints } = require("../socket");

const populate = (q) =>
  q.populate("teamA teamB", "name shortName").populate("tournament", "name sport status").populate("scorer", "name email");

const loadMatch = async (id) => {
  if (!isId(id)) throw new HttpError(400, "Invalid id");
  const m = await populate(Match.findById(id));
  if (!m) throw new HttpError(404, "Match not found");
  return m;
};

// ---------------- reads ----------------
// GET /api/matches?status=live|scheduled|completed&tournament=&team=&limit=&page=
exports.list = wrap(async (req, res) => {
  const { status, tournament, team } = req.query;
  const limit = Math.min(parseInt(req.query.limit) || 20, 100);
  const page = Math.max(parseInt(req.query.page) || 1, 1);

  const filter = {};
  if (status) filter.status = status;
  if (tournament) {
    if (!isId(tournament)) throw new HttpError(400, "Invalid tournament id");
    await loadTournament(tournament, req.user); // visibility check
    filter.tournament = tournament;
  } else {
    filter.tournament = { $in: await approvedTournamentIds() }; // never leak unapproved tournaments
  }
  if (team && isId(team)) filter.$or = [{ teamA: team }, { teamB: team }];

  const sort = status === "completed" ? "-scheduledAt" : status === "scheduled" ? "scheduledAt" : "-updatedAt";
  const [matches, total] = await Promise.all([
    populate(Match.find(filter).sort(sort).skip((page - 1) * limit).limit(limit)),
    Match.countDocuments(filter),
  ]);
  res.json({ matches, total, page, pages: Math.ceil(total / limit) });
});

exports.get = wrap(async (req, res) => {
  const m = await loadMatch(req.params.id);
  await loadTournament(m.tournament._id, req.user);
  res.json({ match: m });
});

// matches assigned to the logged-in scorer
exports.mine = wrap(async (req, res) => {
  const matches = await populate(Match.find({ scorer: req.user._id }).sort("-scheduledAt"));
  res.json({ matches });
});

// ---------------- organiser ----------------
exports.create = wrap(async (req, res) => {
  const t = await loadOwnedTournament(req.params.id, req.user);
  const { teamA, teamB, venue, scheduledAt, scorerEmail } = req.body || {};
  if (!isId(teamA) || !isId(teamB)) throw new HttpError(400, "teamA and teamB are required");
  if (teamA === teamB) throw new HttpError(400, "A team cannot play itself");
  const count = await Team.countDocuments({ _id: { $in: [teamA, teamB] }, tournament: t._id });
  if (count !== 2) throw new HttpError(400, "Both teams must belong to this tournament");

  const data = { tournament: t._id, teamA, teamB, venue: venue || t.venue, scheduledAt: scheduledAt || Date.now() };
  if (scorerEmail) data.scorer = (await findScorer(scorerEmail))._id;
  const m = await Match.create(data);
  res.status(201).json({ match: await loadMatch(m._id) });
});

async function findScorer(email) {
  const u = await User.findOne({ email: String(email).toLowerCase() });
  if (!u || !["scorer", "admin"].includes(u.role)) throw new HttpError(400, "No user with the scorer role has that email");
  return u;
}

exports.assignScorer = wrap(async (req, res) => {
  const m = await loadMatch(req.params.id);
  await loadOwnedTournament(m.tournament._id, req.user);
  const scorer = await findScorer(req.body && req.body.email);
  m.scorer = scorer._id;
  await m.save();
  res.json({ match: await loadMatch(m._id) });
});

exports.remove = wrap(async (req, res) => {
  const m = await loadMatch(req.params.id);
  await loadOwnedTournament(m.tournament._id, req.user);
  if (m.status !== "scheduled") throw new HttpError(409, "Only scheduled matches can be deleted");
  await m.deleteOne();
  res.json({ message: "Match deleted" });
});

// ---------------- scorer ----------------
// A scorer may only touch matches assigned to them (admin may touch any).
async function loadScorable(req) {
  const m = await loadMatch(req.params.id);
  if (req.user.role !== "admin" && String(m.scorer?._id) !== String(req.user._id)) throw new HttpError(403, "You are not the scorer of this match");
  if (m.tournament.status !== "approved") throw new HttpError(409, "Tournament is not approved yet");
  return m;
}

const num = (v, min, max, label) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) throw new HttpError(400, `${label} must be between ${min} and ${max}`);
  return n;
};
// cricket overs are written 12.4 = 12 overs + 4 balls, so the decimal part can only be 0-5
const checkOvers = (n) => {
  if (Math.round((n % 1) * 10) > 5) throw new HttpError(400, "Overs decimal must be 0-5 balls (e.g. 12.4)");
  return n;
};

// PATCH /api/matches/:id/score   { scoreA: {main, wickets, overs}, scoreB: {...}, event: "optional text" }
exports.updateScore = wrap(async (req, res) => {
  const m = await loadScorable(req);
  if (m.status !== "live") throw new HttpError(409, "Match must be live to update the score");
  const cricket = m.tournament.sport === "cricket";

  for (const [key, label] of [["scoreA", m.teamA.name], ["scoreB", m.teamB.name]]) {
    const s = req.body && req.body[key];
    if (!s) continue;
    if (s.main !== undefined) m[key].main = num(s.main, 0, 10000, `${label} score`);
    if (cricket && s.wickets !== undefined) m[key].wickets = num(s.wickets, 0, 10, `${label} wickets`);
    if (cricket && s.overs !== undefined) m[key].overs = checkOvers(num(s.overs, 0, 500, `${label} overs`));
  }
  if (req.body && typeof req.body.note === "string") m.note = req.body.note.slice(0, 200);
  if (req.body && req.body.event) m.events.push({ text: String(req.body.event).slice(0, 120) });
  m.events = m.events.slice(-30);
  await m.save();

  const fresh = await loadMatch(m._id);
  broadcastMatch(fresh);
  res.json({ match: fresh });
});

// PATCH /api/matches/:id/status   { status: "live" | "completed" | "scheduled", winner?: "A"|"B"|"draw", note? }
exports.updateStatus = wrap(async (req, res) => {
  const m = await loadScorable(req);
  const { status, winner, note } = req.body || {};
  if (!["scheduled", "live", "completed"].includes(status)) throw new HttpError(400, "Invalid status");
  const wasCompleted = m.status === "completed";

  m.status = status;
  if (typeof note === "string") m.note = note.slice(0, 200);

  if (status === "completed") {
    // default result = higher score wins, equal = draw/tie; scorer can override (e.g. cricket DLS)
    let w = winner;
    if (!w) w = m.scoreA.main > m.scoreB.main ? "A" : m.scoreB.main > m.scoreA.main ? "B" : "draw";
    if (!["A", "B", "draw"].includes(w)) throw new HttpError(400, "winner must be A, B or draw");
    m.winner = w === "A" ? m.teamA._id : w === "B" ? m.teamB._id : null;
    if (!m.note) m.note = w === "draw" ? "Match drawn" : `${(w === "A" ? m.teamA : m.teamB).name} won`;
  } else {
    m.winner = null;
  }
  m.events.push({ text: `Status: ${status}` });
  m.events = m.events.slice(-30);
  await m.save();

  const fresh = await loadMatch(m._id);
  broadcastMatch(fresh);
  if (status === "completed" || wasCompleted) broadcastPoints(fresh.tournament._id); // points table changed
  res.json({ match: fresh });
});
