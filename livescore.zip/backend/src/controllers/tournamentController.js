const Tournament = require("../models/Tournament");
const Team = require("../models/Team");
const Match = require("../models/Match");
const { HttpError, wrap } = require("../utils/http");
const { isId, loadTournament, loadOwnedTournament } = require("../utils/access");
const { buildPointsTable } = require("../utils/pointsTable");

const SPORTS = ["cricket", "kabaddi", "football"];

// ---------------- tournaments ----------------
exports.list = wrap(async (req, res) => {
  const filter = {};
  if (req.query.mine === "true" && req.user) filter.organiser = req.user._id; // organiser dashboard (any status)
  else filter.status = "approved";
  if (req.query.sport && SPORTS.includes(req.query.sport)) filter.sport = req.query.sport;
  const items = await Tournament.find(filter).populate("organiser", "name").sort("-createdAt");
  res.json({ tournaments: items });
});

exports.get = wrap(async (req, res) => {
  const t = await loadTournament(req.params.id, req.user);
  res.json({ tournament: t });
});

exports.create = wrap(async (req, res) => {
  const { name, sport, description, venue, startDate, endDate } = req.body || {};
  if (!name || !SPORTS.includes(sport)) throw new HttpError(400, `name and sport (${SPORTS.join("/")}) are required`);
  const t = await Tournament.create({ name, sport, description, venue, startDate, endDate, organiser: req.user._id });
  res.status(201).json({ tournament: t });
});

exports.update = wrap(async (req, res) => {
  const t = await loadOwnedTournament(req.params.id, req.user);
  ["name", "description", "venue", "startDate", "endDate"].forEach((k) => req.body[k] !== undefined && (t[k] = req.body[k]));
  await t.save();
  res.json({ tournament: t });
});

exports.points = wrap(async (req, res) => {
  const t = await loadTournament(req.params.id, req.user);
  res.json(await buildPointsTable(t));
});

// ---------------- teams ----------------
exports.listTeams = wrap(async (req, res) => {
  const t = await loadTournament(req.params.id, req.user);
  res.json({ teams: await Team.find({ tournament: t._id }).sort("name") });
});

exports.createTeam = wrap(async (req, res) => {
  const t = await loadOwnedTournament(req.params.id, req.user);
  const { name, shortName, captain, players } = req.body || {};
  if (!name) throw new HttpError(400, "Team name required");
  try {
    const team = await Team.create({
      name, captain, tournament: t._id,
      shortName: shortName || name.replace(/[^a-z0-9]/gi, "").slice(0, 3),
      players: Array.isArray(players) ? players.map(String).filter(Boolean) : String(players || "").split(",").map((s) => s.trim()).filter(Boolean),
    });
    res.status(201).json({ team });
  } catch (e) {
    if (e.code === 11000) throw new HttpError(409, "A team with this name already exists in the tournament");
    throw e;
  }
});

exports.deleteTeam = wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, "Invalid id");
  const team = await Team.findById(req.params.id);
  if (!team) throw new HttpError(404, "Team not found");
  await loadOwnedTournament(team.tournament, req.user);
  if (await Match.exists({ $or: [{ teamA: team._id }, { teamB: team._id }] })) throw new HttpError(409, "Team already has matches");
  await team.deleteOne();
  res.json({ message: "Team deleted" });
});

// Team page: details + record + full match history
exports.getTeam = wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, "Invalid id");
  const team = await Team.findById(req.params.id);
  if (!team) throw new HttpError(404, "Team not found");
  const tournament = await loadTournament(team.tournament, req.user);
  const matches = await Match.find({ $or: [{ teamA: team._id }, { teamB: team._id }] })
    .populate("teamA teamB", "name shortName").sort("-scheduledAt");
  const done = matches.filter((m) => m.status === "completed");
  const won = done.filter((m) => m.winner && String(m.winner) === String(team._id)).length;
  const drawn = done.filter((m) => !m.winner).length;
  res.json({ team, tournament, record: { played: done.length, won, drawn, lost: done.length - won - drawn }, matches });
});
