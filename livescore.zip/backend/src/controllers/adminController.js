const Tournament = require("../models/Tournament");
const User = require("../models/User");
const { HttpError, wrap } = require("../utils/http");
const { isId } = require("../utils/access");

exports.tournaments = wrap(async (req, res) => {
  const filter = ["pending", "approved", "rejected"].includes(req.query.status) ? { status: req.query.status } : {};
  res.json({ tournaments: await Tournament.find(filter).populate("organiser", "name email").sort("-createdAt") });
});

exports.setTournamentStatus = wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, "Invalid id");
  const { status } = req.body || {};
  if (!["approved", "rejected", "pending"].includes(status)) throw new HttpError(400, "status must be approved, rejected or pending");
  const t = await Tournament.findByIdAndUpdate(req.params.id, { status, approvedBy: req.user._id }, { returnDocument: "after" }).populate("organiser", "name email");
  if (!t) throw new HttpError(404, "Tournament not found");
  res.json({ tournament: t });
});

exports.users = wrap(async (req, res) => {
  res.json({ users: await User.find().sort("-createdAt").select("name email role createdAt") });
});

exports.setRole = wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, "Invalid id");
  const { role } = req.body || {};
  if (!["viewer", "scorer", "organiser", "admin"].includes(role)) throw new HttpError(400, "Invalid role");
  if (String(req.user._id) === req.params.id) throw new HttpError(400, "You cannot change your own role");
  const u = await User.findByIdAndUpdate(req.params.id, { role }, { returnDocument: "after" }).select("name email role");
  if (!u) throw new HttpError(404, "User not found");
  res.json({ user: u });
});
