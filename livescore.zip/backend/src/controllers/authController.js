const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");
const { HttpError, wrap } = require("../utils/http");
const { signAccess, signRefresh, hashToken } = require("../utils/tokens");

const PUBLIC_ROLES = ["viewer", "scorer", "organiser"]; // admin can never self-register
const MAX_SESSIONS = 5;

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

async function issueTokens(user) {
  const accessToken = signAccess(user);
  const refreshToken = signRefresh(user);
  const stored = [...(user.refreshTokens || []), hashToken(refreshToken)].slice(-MAX_SESSIONS);
  await User.updateOne({ _id: user._id }, { refreshTokens: stored });
  return { accessToken, refreshToken };
}

exports.register = wrap(async (req, res) => {
  const { name, email, password, role = "viewer" } = req.body || {};
  if (!name || !email || !password) throw new HttpError(400, "name, email and password are required");
  if (!/^\S+@\S+\.\S+$/.test(email)) throw new HttpError(400, "Invalid email");
  if (password.length < 6) throw new HttpError(400, "Password must be at least 6 characters");
  if (!PUBLIC_ROLES.includes(role)) throw new HttpError(400, `Role must be one of: ${PUBLIC_ROLES.join(", ")}`);
  if (await User.exists({ email: email.toLowerCase() })) throw new HttpError(409, "Email already registered");

  const user = await User.create({ name, email, role, password: await bcrypt.hash(password, 10) });
  const tokens = await issueTokens(user);
  res.status(201).json({ user: publicUser(user), ...tokens });
});

exports.login = wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) throw new HttpError(400, "email and password are required");
  const user = await User.findOne({ email: email.toLowerCase() }).select("+password +refreshTokens");
  if (!user || !(await bcrypt.compare(password, user.password))) throw new HttpError(401, "Invalid email or password");
  const tokens = await issueTokens(user);
  res.json({ user: publicUser(user), ...tokens });
});

// Refresh-token rotation: old token is removed, a new pair is issued.
exports.refresh = wrap(async (req, res) => {
  const { refreshToken } = req.body || {};
  if (!refreshToken) throw new HttpError(400, "refreshToken required");
  let payload;
  try {
    payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
  } catch {
    throw new HttpError(401, "Invalid or expired refresh token");
  }
  const user = await User.findById(payload.sub).select("+refreshTokens");
  const h = hashToken(refreshToken);
  if (!user || !user.refreshTokens.includes(h)) {
    // reuse of a rotated token => revoke every session of that user
    if (user) await User.updateOne({ _id: user._id }, { refreshTokens: [] });
    throw new HttpError(401, "Refresh token revoked");
  }
  user.refreshTokens = user.refreshTokens.filter((t) => t !== h);
  await user.save();
  const tokens = await issueTokens(user);
  res.json({ user: publicUser(user), ...tokens });
});

exports.logout = wrap(async (req, res) => {
  const { refreshToken } = req.body || {};
  if (refreshToken) {
    await User.updateOne({ refreshTokens: hashToken(refreshToken) }, { $pull: { refreshTokens: hashToken(refreshToken) } });
  }
  res.json({ message: "Logged out" });
});

exports.me = (req, res) => res.json({ user: publicUser(req.user) });
