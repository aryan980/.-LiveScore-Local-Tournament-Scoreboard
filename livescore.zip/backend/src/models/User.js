const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    role: { type: String, enum: ["viewer", "scorer", "organiser", "admin"], default: "viewer" },
    // SHA-256 hashes of the refresh tokens currently valid for this user (rotation + revocation)
    refreshTokens: { type: [String], default: [], select: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
