const mongoose = require("mongoose");

// Score of one side. `main` = goals (football) / points (kabaddi) / runs (cricket).
// wickets + overs are only used for cricket.
const sideSchema = new mongoose.Schema(
  { main: { type: Number, default: 0, min: 0 }, wickets: { type: Number, default: 0, min: 0, max: 10 }, overs: { type: Number, default: 0, min: 0 } },
  { _id: false }
);

const matchSchema = new mongoose.Schema(
  {
    tournament: { type: mongoose.Schema.Types.ObjectId, ref: "Tournament", required: true, index: true },
    teamA: { type: mongoose.Schema.Types.ObjectId, ref: "Team", required: true },
    teamB: { type: mongoose.Schema.Types.ObjectId, ref: "Team", required: true },
    scorer: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    venue: { type: String, trim: true, default: "" },
    scheduledAt: { type: Date, default: Date.now },
    status: { type: String, enum: ["scheduled", "live", "completed"], default: "scheduled", index: true },
    scoreA: { type: sideSchema, default: () => ({}) },
    scoreB: { type: sideSchema, default: () => ({}) },
    // winner null + completed => tie / draw
    winner: { type: mongoose.Schema.Types.ObjectId, ref: "Team", default: null },
    note: { type: String, trim: true, maxlength: 200, default: "" }, // e.g. "Half time", "Won by 12 runs"
    // short log of score changes shown on the match page
    events: {
      type: [{ text: String, at: { type: Date, default: Date.now }, _id: false }],
      default: [],
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Match", matchSchema);
