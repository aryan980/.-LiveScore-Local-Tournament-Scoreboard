const mongoose = require("mongoose");

const teamSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    shortName: { type: String, trim: true, uppercase: true, maxlength: 5 },
    tournament: { type: mongoose.Schema.Types.ObjectId, ref: "Tournament", required: true, index: true },
    captain: { type: String, trim: true, default: "" },
    players: { type: [String], default: [] },
  },
  { timestamps: true }
);
teamSchema.index({ tournament: 1, name: 1 }, { unique: true });

module.exports = mongoose.model("Team", teamSchema);
