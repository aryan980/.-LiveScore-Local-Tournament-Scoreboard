const mongoose = require("mongoose");

const tournamentSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    sport: { type: String, enum: ["cricket", "kabaddi", "football"], required: true },
    description: { type: String, trim: true, maxlength: 500, default: "" },
    venue: { type: String, trim: true, default: "" },
    startDate: Date,
    endDate: Date,
    organiser: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    // admin approves tournaments before they are visible to the public
    status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Tournament", tournamentSchema);
