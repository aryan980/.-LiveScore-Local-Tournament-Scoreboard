const express = require("express");
const routes = require("./routes");

const app = express();
app.use(express.json({ limit: "100kb" }));

// minimal CORS (frontend dev server runs on another port)
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", process.env.CLIENT_URL || "http://localhost:5173");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PATCH,DELETE,OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use("/api", routes);
app.use("/api", (req, res) => res.status(404).json({ message: "Route not found" }));

// central error handler
app.use((err, req, res, next) => {
  if (err.name === "ValidationError") return res.status(400).json({ message: Object.values(err.errors).map((e) => e.message).join(", ") });
  if (err.name === "CastError") return res.status(400).json({ message: "Invalid id" });
  if (!err.status) console.error(err);
  res.status(err.status || 500).json({ message: err.status ? err.message : "Internal server error" });
});

module.exports = app;
