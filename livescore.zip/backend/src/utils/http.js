class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
// Express 5 forwards rejected promises to the error handler, but this keeps intent explicit
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
module.exports = { HttpError, wrap };
