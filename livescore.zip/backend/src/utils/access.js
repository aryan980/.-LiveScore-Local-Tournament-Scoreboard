const mongoose = require("mongoose");
const Tournament = require("../models/Tournament");
const { HttpError } = require("./http");

const isId = (id) => mongoose.isValidObjectId(id);

// Loads a tournament and enforces visibility:
// unapproved tournaments are only visible to their organiser and to admins.
async function loadTournament(id, user) {
  if (!isId(id)) throw new HttpError(400, "Invalid id");
  const t = await Tournament.findById(id).populate("organiser", "name");
  if (!t) throw new HttpError(404, "Tournament not found");
  const privileged = user && (user.role === "admin" || String(t.organiser._id) === String(user._id));
  if (t.status !== "approved" && !privileged) throw new HttpError(404, "Tournament not found");
  return t;
}

// Same as above but the caller must be the owner (or admin)
async function loadOwnedTournament(id, user) {
  const t = await loadTournament(id, user);
  if (user.role !== "admin" && String(t.organiser._id) !== String(user._id)) throw new HttpError(403, "Not your tournament");
  return t;
}

const approvedTournamentIds = async () => (await Tournament.find({ status: "approved" }).select("_id")).map((t) => t._id);

module.exports = { isId, loadTournament, loadOwnedTournament, approvedTournamentIds };
