const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const signAccess = (user) =>
  jwt.sign({ sub: user._id.toString(), role: user.role }, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.ACCESS_TOKEN_TTL || "15m",
  });

// jti makes every refresh token unique even if issued in the same second
const signRefresh = (user) =>
  jwt.sign({ sub: user._id.toString(), jti: crypto.randomUUID() }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.REFRESH_TOKEN_TTL || "7d",
  });

const hashToken = (t) => crypto.createHash("sha256").update(t).digest("hex");

module.exports = { signAccess, signRefresh, hashToken };
