const mongoose = require("mongoose");
const Match = require("../models/Match");
const Team = require("../models/Team");

// Points awarded per sport: [win, draw/tie, loss]
const POINTS = {
  football: { win: 3, draw: 1, loss: 0 },
  cricket: { win: 2, draw: 1, loss: 0 },
  kabaddi: { win: 2, draw: 1, loss: 0 },
};

/**
 * Auto-generated points table, calculated with a MongoDB aggregation.
 *
 * 1. $match      -> only completed matches of this tournament
 * 2. $project    -> turn each match into TWO "team rows" (home + away) with for/against + result flags
 * 3. $unwind     -> one document per team per match
 * 4. $group      -> sum played / won / lost / drawn / points / for / against per team
 * 5. $lookup     -> attach team name
 * 6. $sort       -> points desc, score difference desc, wins desc
 *
 * Teams that have not played yet are appended afterwards with zeros so every team shows up.
 */
async function buildPointsTable(tournament) {
  const tid = new mongoose.Types.ObjectId(tournament._id);
  const pts = POINTS[tournament.sport] || POINTS.football;

  const rows = await Match.aggregate([
    { $match: { tournament: tid, status: "completed" } },
    {
      $project: {
        sides: [
          {
            team: "$teamA",
            scored: "$scoreA.main",
            conceded: "$scoreB.main",
            won: { $cond: [{ $eq: ["$winner", "$teamA"] }, 1, 0] },
            lost: { $cond: [{ $and: [{ $ne: ["$winner", null] }, { $ne: ["$winner", "$teamA"] }] }, 1, 0] },
            drawn: { $cond: [{ $eq: ["$winner", null] }, 1, 0] },
          },
          {
            team: "$teamB",
            scored: "$scoreB.main",
            conceded: "$scoreA.main",
            won: { $cond: [{ $eq: ["$winner", "$teamB"] }, 1, 0] },
            lost: { $cond: [{ $and: [{ $ne: ["$winner", null] }, { $ne: ["$winner", "$teamB"] }] }, 1, 0] },
            drawn: { $cond: [{ $eq: ["$winner", null] }, 1, 0] },
          },
        ],
      },
    },
    { $unwind: "$sides" },
    {
      $group: {
        _id: "$sides.team",
        played: { $sum: 1 },
        won: { $sum: "$sides.won" },
        lost: { $sum: "$sides.lost" },
        drawn: { $sum: "$sides.drawn" },
        scored: { $sum: "$sides.scored" },
        conceded: { $sum: "$sides.conceded" },
      },
    },
    {
      $addFields: {
        points: { $add: [{ $multiply: ["$won", pts.win] }, { $multiply: ["$drawn", pts.draw] }, { $multiply: ["$lost", pts.loss] }] },
        diff: { $subtract: ["$scored", "$conceded"] },
      },
    },
    { $lookup: { from: Team.collection.name, localField: "_id", foreignField: "_id", as: "team" } },
    { $unwind: "$team" },
    { $project: { _id: 0, teamId: "$_id", name: "$team.name", shortName: "$team.shortName", played: 1, won: 1, lost: 1, drawn: 1, scored: 1, conceded: 1, diff: 1, points: 1 } },
    { $sort: { points: -1, diff: -1, won: -1, name: 1 } },
  ]);

  const seen = new Set(rows.map((r) => String(r.teamId)));
  const idle = await Team.find({ tournament: tid, _id: { $nin: [...seen] } }).sort("name");
  idle.forEach((t) =>
    rows.push({ teamId: t._id, name: t.name, shortName: t.shortName, played: 0, won: 0, lost: 0, drawn: 0, scored: 0, conceded: 0, diff: 0, points: 0 })
  );
  return { sport: tournament.sport, rules: pts, rows: rows.map((r, i) => ({ position: i + 1, ...r })) };
}

module.exports = { buildPointsTable, POINTS };
