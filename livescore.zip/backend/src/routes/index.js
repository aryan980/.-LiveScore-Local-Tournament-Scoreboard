const router = require("express").Router();
const { authenticate, optionalAuth, authorize } = require("../middleware/auth");
const auth = require("../controllers/authController");
const tour = require("../controllers/tournamentController");
const match = require("../controllers/matchController");
const admin = require("../controllers/adminController");

// ---- auth ----
router.post("/auth/register", auth.register);
router.post("/auth/login", auth.login);
router.post("/auth/refresh", auth.refresh);
router.post("/auth/logout", auth.logout);
router.get("/auth/me", authenticate, auth.me);

// ---- public (viewer) reads; unapproved tournaments only visible to owner/admin ----
router.get("/tournaments", optionalAuth, tour.list);
router.get("/tournaments/:id", optionalAuth, tour.get);
router.get("/tournaments/:id/teams", optionalAuth, tour.listTeams);
router.get("/tournaments/:id/points", optionalAuth, tour.points);
router.get("/teams/:id", optionalAuth, tour.getTeam);
router.get("/matches", optionalAuth, match.list);
router.get("/matches/:id", optionalAuth, match.get);

// ---- organiser routes (RBAC) ----
const org = [authenticate, authorize("organiser")];
router.post("/tournaments", ...org, tour.create);
router.patch("/tournaments/:id", ...org, tour.update);
router.post("/tournaments/:id/teams", ...org, tour.createTeam);
router.delete("/teams/:id", ...org, tour.deleteTeam);
router.post("/tournaments/:id/matches", ...org, match.create);
router.patch("/matches/:id/scorer", ...org, match.assignScorer);
router.delete("/matches/:id", ...org, match.remove);

// ---- scorer routes (RBAC) ----
const sc = [authenticate, authorize("scorer")];
router.get("/scorer/matches", ...sc, match.mine);
router.patch("/matches/:id/score", ...sc, match.updateScore);
router.patch("/matches/:id/status", ...sc, match.updateStatus);

// ---- admin routes ----
const adm = [authenticate, authorize("admin")];
router.get("/admin/tournaments", ...adm, admin.tournaments);
router.patch("/admin/tournaments/:id/status", ...adm, admin.setTournamentStatus);
router.get("/admin/users", ...adm, admin.users);
router.patch("/admin/users/:id/role", ...adm, admin.setRole);

module.exports = router;
