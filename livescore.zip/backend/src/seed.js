// Creates the first admin (admins cannot self-register). Usage: npm run seed
require("dotenv").config({ quiet: true });
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const User = require("./models/User");

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  const email = (process.env.ADMIN_EMAIL || "admin@livescore.local").toLowerCase();
  const existing = await User.findOne({ email });
  if (existing) {
    existing.role = "admin";
    await existing.save();
    console.log(`Existing user ${email} promoted to admin`);
  } else {
    await User.create({ name: process.env.ADMIN_NAME || "Admin", email, role: "admin", password: await bcrypt.hash(process.env.ADMIN_PASSWORD || "Admin@12345", 10) });
    console.log(`Admin created: ${email}`);
  }
  await mongoose.disconnect();
})();
