const { Server } = require("socket.io");

let io;

// Viewers subscribe to rooms; the REST controllers broadcast into them after every DB write.
//   feed            -> every live/status change (home page)
//   match:<id>      -> one match scoreboard
//   tournament:<id> -> matches + points table of a tournament
function init(httpServer) {
  io = new Server(httpServer, { cors: { origin: process.env.CLIENT_URL || "http://localhost:5173" } });
  const ok = (id) => typeof id === "string" && /^[a-f\d]{24}$/i.test(id);

  io.on("connection", (socket) => {
    socket.on("watch:feed", () => socket.join("feed"));
    socket.on("watch:match", (id) => ok(id) && socket.join(`match:${id}`));
    socket.on("unwatch:match", (id) => ok(id) && socket.leave(`match:${id}`));
    socket.on("watch:tournament", (id) => ok(id) && socket.join(`tournament:${id}`));
    socket.on("unwatch:tournament", (id) => ok(id) && socket.leave(`tournament:${id}`));
  });
  return io;
}

// Called from controllers; no-op if sockets are not initialised (e.g. in unit tests)
function broadcastMatch(match) {
  if (!io) return;
  const tid = String(match.tournament._id || match.tournament);
  io.to(`match:${match._id}`).to(`tournament:${tid}`).to("feed").emit("match:update", match);
}
function broadcastPoints(tournamentId) {
  if (io) io.to(`tournament:${tournamentId}`).emit("points:update", { tournamentId: String(tournamentId) });
}

module.exports = { init, broadcastMatch, broadcastPoints };
