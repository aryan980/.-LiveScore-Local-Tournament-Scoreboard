// End-to-end API test using an in-memory MongoDB.  Run: npm test
process.env.JWT_ACCESS_SECRET = "a"; process.env.JWT_REFRESH_SECRET = "b"; process.env.CLIENT_URL = "*";
const http = require("http");
const assert = require("assert");
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const { MongoMemoryServer } = require("mongodb-memory-server");
const { io: ioc } = require("socket.io-client");
const app = require("../src/app");
const { init } = require("../src/socket");
const User = require("../src/models/User");

let base, passed = 0;
const api = async (method, path, body, token) => {
  const r = await fetch(base + path, { method, headers: { "Content-Type": "application/json", ...(token && { Authorization: "Bearer " + token }) }, body: body && JSON.stringify(body) });
  return { status: r.status, ...(await r.json().catch(() => ({}))) };
};
const t = async (name, fn) => { await fn(); passed++; console.log("  ok -", name); };

(async () => {
  // Use a real MongoDB if MONGO_URI is given, otherwise spin up an in-memory one
  const mongod = process.env.TEST_MONGO_URI ? null : await MongoMemoryServer.create();
  const uri = process.env.TEST_MONGO_URI || mongod.getUri();
  await mongoose.connect(uri);
  await mongoose.connection.dropDatabase();
  const server = http.createServer(app); init(server);
  await new Promise((r) => server.listen(0, r));
  base = `http://localhost:${server.address().port}/api`;

  await User.create({ name: "Admin", email: "admin@x.com", role: "admin", password: await bcrypt.hash("secret1", 10) });
  const reg = (name, role) => api("POST", "/auth/register", { name, email: `${name}@x.com`, password: "secret1", role });
  const org = await reg("org", "organiser"), sco = await reg("sco", "scorer"), vw = await reg("vw", "viewer");
  const adm = await api("POST", "/auth/login", { email: "admin@x.com", password: "secret1" });

  await t("register/login return tokens; password is hashed", async () => {
    assert(org.accessToken && org.refreshToken);
    assert.strictEqual((await api("POST", "/auth/register", { name: "x", email: "z@x.com", password: "secret1", role: "admin" })).status, 400);
    assert.strictEqual((await api("POST", "/auth/login", { email: "org@x.com", password: "bad" })).status, 401);
    const u = await User.findOne({ email: "org@x.com" }).select("+password");
    assert(u.password.startsWith("$2"));
  });
  await t("refresh rotates token and old one is revoked", async () => {
    const r1 = await api("POST", "/auth/refresh", { refreshToken: vw.refreshToken });
    assert(r1.accessToken && r1.refreshToken !== vw.refreshToken);
    assert.strictEqual((await api("POST", "/auth/refresh", { refreshToken: vw.refreshToken })).status, 401);
  });
  await t("RBAC: viewer cannot create tournament, scorer cannot either", async () => {
    assert.strictEqual((await api("POST", "/tournaments", { name: "N", sport: "football" }, vw.accessToken)).status, 403);
    assert.strictEqual((await api("POST", "/tournaments", { name: "N", sport: "football" }, sco.accessToken)).status, 403);
    assert.strictEqual((await api("POST", "/tournaments", { name: "N", sport: "football" })).status, 401);
  });

  const tr = await api("POST", "/tournaments", { name: "College Cup", sport: "football" }, org.accessToken);
  const tid = tr.tournament._id;
  await t("unapproved tournament hidden from public, visible to owner", async () => {
    assert.strictEqual((await api("GET", "/tournaments")).tournaments.length, 0);
    assert.strictEqual((await api("GET", "/tournaments/" + tid)).status, 404);
    assert.strictEqual((await api("GET", "/tournaments/" + tid, null, org.accessToken)).status, 200);
  });
  await t("only admin can approve", async () => {
    assert.strictEqual((await api("PATCH", `/admin/tournaments/${tid}/status`, { status: "approved" }, org.accessToken)).status, 403);
    assert.strictEqual((await api("PATCH", `/admin/tournaments/${tid}/status`, { status: "approved" }, adm.accessToken)).tournament.status, "approved");
    assert.strictEqual((await api("GET", "/tournaments")).tournaments.length, 1);
  });

  const mk = async (n) => (await api("POST", `/tournaments/${tid}/teams`, { name: n, players: "a, b" }, org.accessToken)).team._id;
  const [A, B, C] = [await mk("Lions"), await mk("Tigers"), await mk("Bears")];
  const mm = async (a, b) => (await api("POST", `/tournaments/${tid}/matches`, { teamA: a, teamB: b, scorerEmail: "sco@x.com" }, org.accessToken)).match._id;
  const [m1, m2, m3] = [await mm(A, B), await mm(A, C), await mm(B, C)];

  await t("team validation (duplicate name, foreign team)", async () => {
    assert.strictEqual((await api("POST", `/tournaments/${tid}/teams`, { name: "Lions" }, org.accessToken)).status, 409);
    assert.strictEqual((await api("POST", `/tournaments/${tid}/matches`, { teamA: A, teamB: A }, org.accessToken)).status, 400);
  });

  // live socket client on match 1
  const sock = ioc(base.replace("/api", ""), { transports: ["websocket"] });
  await new Promise((r) => sock.on("connect", r));
  sock.emit("watch:match", m1);
  await new Promise((r) => setTimeout(r, 100));
  const live = new Promise((res) => sock.on("match:update", res));

  await t("scorer: must be assigned + match must be live", async () => {
    const sco2 = await api("POST", "/auth/register", { name: "sco2", email: "sco2@x.com", password: "secret1", role: "scorer" });
    assert.strictEqual((await api("PATCH", `/matches/${m1}/status`, { status: "live" }, sco2.accessToken)).status, 403);
    assert.strictEqual((await api("PATCH", `/matches/${m1}/score`, { scoreA: { main: 1 } }, sco.accessToken)).status, 409);
    assert.strictEqual((await api("PATCH", `/matches/${m1}/status`, { status: "live" }, sco.accessToken)).match.status, "live");
  });
  await t("viewer receives live score over socket.io", async () => {
    await api("PATCH", `/matches/${m1}/score`, { scoreA: { main: 2 }, scoreB: { main: 1 }, event: "Goal!" }, sco.accessToken);
    const msg = await Promise.race([live, new Promise((_, rej) => setTimeout(() => rej(new Error("no socket event")), 2000))]);
    assert.strictEqual(msg._id, m1);
  });
  await t("score validation", async () => {
    assert.strictEqual((await api("PATCH", `/matches/${m1}/score`, { scoreA: { main: -3 } }, sco.accessToken)).status, 400);
  });

  const finish = async (id, a, b) => {
    await api("PATCH", `/matches/${id}/status`, { status: "live" }, sco.accessToken);
    await api("PATCH", `/matches/${id}/score`, { scoreA: { main: a }, scoreB: { main: b } }, sco.accessToken);
    return api("PATCH", `/matches/${id}/status`, { status: "completed" }, sco.accessToken);
  };
  await finish(m1, 2, 1); // Lions beat Tigers
  await finish(m2, 0, 0); // Lions draw Bears
  await finish(m3, 0, 3); // Bears beat Tigers

  await t("points table (aggregation): P/W/L/D/points, football 3-1-0", async () => {
    const pt = await api("GET", `/tournaments/${tid}/points`);
    const row = (n) => pt.rows.find((r) => r.name === n);
    assert.deepStrictEqual([row("Lions").played, row("Lions").won, row("Lions").drawn, row("Lions").points], [2, 1, 1, 4]);
    assert.deepStrictEqual([row("Bears").played, row("Bears").won, row("Bears").drawn, row("Bears").points], [2, 1, 1, 4]);
    assert.deepStrictEqual([row("Tigers").played, row("Tigers").lost, row("Tigers").points], [2, 2, 0]);
    assert.strictEqual(row("Bears").diff, 3); // Bears ranked first on goal difference
    assert.strictEqual(pt.rows[0].name, "Bears");
  });
  await t("match history + team page", async () => {
    const h = await api("GET", "/matches?status=completed");
    assert.strictEqual(h.total, 3);
    const tp = await api("GET", "/teams/" + A);
    assert.deepStrictEqual(tp.record, { played: 2, won: 1, drawn: 1, lost: 0 });
  });
  await t("cricket overs validation", async () => {
    const ct = (await api("POST", "/tournaments", { name: "Box Cricket", sport: "cricket" }, org.accessToken)).tournament._id;
    await api("PATCH", `/admin/tournaments/${ct}/status`, { status: "approved" }, adm.accessToken);
    const [x, y] = [(await api("POST", `/tournaments/${ct}/teams`, { name: "X" }, org.accessToken)).team._id, (await api("POST", `/tournaments/${ct}/teams`, { name: "Y" }, org.accessToken)).team._id];
    const m = (await api("POST", `/tournaments/${ct}/matches`, { teamA: x, teamB: y, scorerEmail: "sco@x.com" }, org.accessToken)).match._id;
    await api("PATCH", `/matches/${m}/status`, { status: "live" }, sco.accessToken);
    assert.strictEqual((await api("PATCH", `/matches/${m}/score`, { scoreA: { main: 50, wickets: 2, overs: 5.4 } }, sco.accessToken)).status, 200);
    assert.strictEqual((await api("PATCH", `/matches/${m}/score`, { scoreA: { overs: 5.7 } }, sco.accessToken)).status, 400);
  });
  await t("admin: list users + change role; cannot change own", async () => {
    const us = await api("GET", "/admin/users", null, adm.accessToken);
    assert(us.users.length >= 4);
    const v = us.users.find((u) => u.email === "vw@x.com");
    assert.strictEqual((await api("PATCH", `/admin/users/${v._id}/role`, { role: "scorer" }, adm.accessToken)).user.role, "scorer");
  });

  console.log(`\n${passed} tests passed`);
  sock.close(); server.close(); await mongoose.disconnect(); if (mongod) await mongod.stop(); process.exit(0);
})().catch((e) => { console.error("FAILED:", e); process.exit(1); });
