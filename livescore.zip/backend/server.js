require("dotenv").config({ quiet: true });
const http = require("http");
const mongoose = require("mongoose");
const app = require("./src/app");
const { init } = require("./src/socket");

const PORT = process.env.PORT || 5000;

(async () => {
  for (const k of ["MONGO_URI", "JWT_ACCESS_SECRET", "JWT_REFRESH_SECRET"]) {
    if (!process.env[k]) { console.error(`Missing ${k} in .env`); process.exit(1); }
  }
  await mongoose.connect(process.env.MONGO_URI);
  console.log("MongoDB connected");
  const server = http.createServer(app);
  init(server);
  server.listen(PORT, () => console.log(`LiveScore API + Socket.IO on http://localhost:${PORT}`));
})().catch((e) => { console.error(e); process.exit(1); });
