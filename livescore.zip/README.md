# 🏆 LiveScore: Local Tournament Scoreboard

Live scoreboard for college & street tournaments (cricket, kabaddi, football). Scorers update the match, viewers see it change **instantly, with no refresh**.

**Stack:** Express · Mongoose · dotenv · bcrypt · jsonwebtoken · Socket.IO | React (Vite) · react-router-dom · Fetch API · Context API · socket.io-client

## Quick start

Needs Node 18+ and MongoDB (local or Atlas).

```bash
# 1. backend
cd backend
npm install
cp .env.example .env        # edit MONGO_URI + the two JWT secrets
npm run seed                # creates the first admin (see ADMIN_* in .env)
npm run dev                 # API + Socket.IO on http://localhost:5000

# 2. frontend (new terminal)
cd frontend
npm install
npm run dev                 # http://localhost:5173  (Vite proxies /api and /socket.io to :5000)
```

Default admin (change in `.env` before seeding): `admin@livescore.local` / `Admin@12345`

Run backend tests: `cd backend && npm test` (end-to-end, uses an in-memory MongoDB; set `TEST_MONGO_URI` to use your own).

## Roles (RBAC)

| Role | Can do |
|---|---|
| **viewer** | Watch live matches, tournaments, points tables, team pages, history |
| **scorer** | Update score + status of matches **assigned to them** |
| **organiser** | Create tournaments, teams, matches; assign scorers |
| **admin** | Approve / reject tournaments; manage user roles (created via `npm run seed`, cannot self-register) |

Enforced on the server by `authenticate` + `authorize(...roles)` middleware (`backend/src/middleware/auth.js`) and mirrored on the client by `ProtectedRoute`.

## Authentication
* Passwords hashed with **bcrypt** (10 rounds).
* **Access token** (JWT, 15 min) sent as `Authorization: Bearer`.
* **Refresh token** (JWT, 7 days) with **rotation**: only a SHA-256 hash is stored in the DB; every refresh invalidates the old token; re-using an old one revokes all sessions. The frontend's `api.js` refreshes transparently on a 401.

## ⭐ Unique twist: auto points table
`GET /api/tournaments/:id/points` runs a MongoDB **aggregation** (`backend/src/utils/pointsTable.js`):
`$match` (completed) → `$project` (each match → 2 team rows) → `$unwind` → `$group` (played / won / lost / drawn / scored / conceded) → `$addFields` (points, diff) → `$lookup` (team names) → `$sort`.
Points: football **3-1-0**, cricket & kabaddi **2-1-0** (win-draw/tie-loss). Ties broken by score difference, then wins. The table re-fetches live whenever a match finishes.

## Live updates (Socket.IO)
Rooms: `feed` (home page), `match:<id>`, `tournament:<id>`. Client → server: `watch:feed`, `watch:match`, `watch:tournament` (+ `unwatch:*`). Server → client: `match:update` (full match after any score/status change) and `points:update`.
REST controllers write to MongoDB first, then broadcast, so the database is always the source of truth.

## Main API
```
POST /api/auth/register | login | refresh | logout        GET /api/auth/me
GET  /api/tournaments[?sport=&mine=true]  /:id  /:id/teams  /:id/points
GET  /api/matches?status=&tournament=&team=&page=&limit=  /:id       GET /api/teams/:id
POST /api/tournaments                    (organiser)   PATCH /api/tournaments/:id
POST /api/tournaments/:id/teams          (organiser)   DELETE /api/teams/:id
POST /api/tournaments/:id/matches        (organiser)   PATCH /api/matches/:id/scorer   DELETE /api/matches/:id
GET  /api/scorer/matches                 (scorer)
PATCH /api/matches/:id/score             (scorer)  { scoreA:{main,wickets,overs}, scoreB:{...}, note, event }
PATCH /api/matches/:id/status            (scorer)  { status: live|completed|scheduled, winner?: A|B|draw }
GET  /api/admin/tournaments  PATCH /api/admin/tournaments/:id/status   (admin)
GET  /api/admin/users        PATCH /api/admin/users/:id/role           (admin)
```

## Typical walkthrough (demo)
1. Register an **organiser** and a **scorer** (Sign up page); log in as seeded **admin**.
2. Organiser → create tournament → appears as *pending*.
3. Admin → approve it.
4. Organiser → add teams → schedule matches, entering the scorer's email.
5. Scorer → *Start match*, tap +1 / wickets / balls. Open the match page in another browser (viewer): it updates live.
6. Scorer → *End match* → winner computed, points table updates for everyone.

## Notes / design decisions
* Unapproved tournaments are hidden from the public (including their matches/teams) and cannot be scored.
* Cricket: runs / wickets / overs (`12.4` = 12 overs 4 balls; server rejects `.6`+). Result defaults to the higher score; scorer can override (tie, DLS...).
* Admin can't be created through the UI, by design, so nobody can grant themselves admin.
* Production: set strong JWT secrets, `CLIENT_URL` to your frontend origin, `VITE_API_URL` to your API origin before `npm run build`.

## Structure
```
backend/  server.js, src/{app,socket,seed}.js, models/, controllers/, routes/, middleware/, utils/, test/e2e.js
frontend/ src/{api,socket,hooks,utils}.js, context/AuthContext.jsx, components/, pages/
```
